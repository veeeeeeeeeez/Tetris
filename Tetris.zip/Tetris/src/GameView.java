// Vincent Z
// Section A
// Final Project - Tetris
// Blueprint of the Game View, for code usability (if I made Snake)
// GameView.java
// 7/30/20

import java.awt.*;

public class GameView {

	// instance variable for the drawing panel of the game.
	protected DrawingPanel panel;
	// instance variable for the graphics2d pen to be used to draw stuff in
	// the game's game view.
	public Graphics2D g;

	/**
	 * constructs a new game view.
	 */
	public GameView() {

	}

	/**
	 * draws the game view.
	 */
	protected void draw() {

	}
}